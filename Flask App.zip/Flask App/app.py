from flask import Flask, render_template, request
import os
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'mp4'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    uploaded_file_url = None
    file_type = None

    if request.method == 'POST':
        file = request.files.get('media')
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            uploaded_file_url = f"{app.config['UPLOAD_FOLDER']}/{filename}"
            ext = filename.rsplit('.', 1)[1].lower()
            file_type = 'image' if ext in {'png', 'jpg', 'jpeg'} else 'video'

    return render_template('index.html', file_url=uploaded_file_url, file_type=file_type)

if __name__ == '__main__':
    app.run(debug=True)
